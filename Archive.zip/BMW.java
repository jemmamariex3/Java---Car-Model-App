//Jemma Tiongson
//App: Driver.java (Vehicle Polymorphism)
//Purpose: Exam - testing knowledge of Polymorphism and abstract

public class BMW extends Vehicle{
   public int getTotalPrice(){
      return basePrice + 5000;
   }
}